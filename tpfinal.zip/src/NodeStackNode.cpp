#include "NodeStackNode.hpp"

NodeStackNode::NodeStackNode(TreeNode* n){
    this->data = n;
    this->link = nullptr;
}